
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Lead, Listing, Project, Agent, UnitType } from '../types';
import { UsersIcon } from './icons/UsersIcon';
import { ClipboardListIcon } from './icons/ClipboardListIcon';
import { MapPinIcon } from './icons/MapPinIcon';
import { BuildingOfficeIcon } from './icons/BuildingOfficeIcon';

interface DashboardProps {
    leads: Lead[];
    listings: Listing[];
    projects: Project[];
    leadPoolCount: number;
    agents: Agent[];
}

const StatCard: React.FC<{ title: string; value: string | number; icon: React.ReactNode }> = ({ title, value, icon }) => (
    <div className="bg-white p-6 rounded-lg shadow-md flex items-center">
        <div className="bg-mapstone-blue text-white rounded-full p-3">
            {icon}
        </div>
        <div className="ml-4">
            <p className="text-sm font-medium text-gray-500">{title}</p>
            <p className="text-2xl font-bold text-mapstone-dark">{value}</p>
        </div>
    </div>
);

const ChartContainer: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-lg font-semibold text-mapstone-dark mb-4">{title}</h3>
        <div style={{ width: '100%', height: 300 }}>
            {children}
        </div>
    </div>
);

const Dashboard: React.FC<DashboardProps> = ({ leads, listings, projects, leadPoolCount, agents }) => {
    const activeListings = listings.filter(l => l.status === 'Active' && l.sellerApproval).length;
    const activeProjects = projects.length;

    const leadsByAgent = agents.map(agent => ({
        name: agent.name.split(' ')[0],
        leads: leads.filter(lead => lead.assignedAgent === agent.id).length
    }));

    const listingsByType = Object.values(UnitType).map(type => ({
        name: type,
        count: listings.filter(l => l.unitType === type).length
    })).filter(item => item.count > 0);

    const leadsByLanguage = [
        { name: 'English', value: leads.filter(l => l.language === 'EN').length },
        { name: 'French', value: leads.filter(l => l.language === 'FR').length },
        { name: 'Arabic', value: leads.filter(l => l.language === 'AR').length },
        { name: 'Russian', value: leads.filter(l => l.language === 'RU').length },
    ].filter(l => l.value > 0);

    const COLORS = ['#2e5a88', '#d4a017', '#1a2a44', '#7d8a9b'];

    return (
        <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard title="Total Leads" value={leads.length} icon={<UsersIcon className="h-6 w-6" />} />
                <StatCard title="Lead Pool" value={leadPoolCount} icon={<ClipboardListIcon className="h-6 w-6" />} />
                <StatCard title="Active Listings" value={activeListings} icon={<MapPinIcon className="h-6 w-6" />} />
                <StatCard title="Active Projects" value={activeProjects} icon={<BuildingOfficeIcon className="h-6 w-6" />} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <ChartContainer title="Leads by Agent">
                        <ResponsiveContainer>
                            <BarChart data={leadsByAgent} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="name" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Bar dataKey="leads" fill="#2e5a88" />
                            </BarChart>
                        </ResponsiveContainer>
                    </ChartContainer>
                </div>
                <div>
                     <ChartContainer title="Leads by Language">
                        <ResponsiveContainer>
                            <PieChart>
                                <Pie data={leadsByLanguage} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                                    {leadsByLanguage.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip />
                                <Legend />
                            </PieChart>
                        </ResponsiveContainer>
                    </ChartContainer>
                </div>
            </div>

             <div className="grid grid-cols-1">
                 <ChartContainer title="Listings by Type">
                     <ResponsiveContainer>
                         <BarChart data={listingsByType} layout="vertical" margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                             <CartesianGrid strokeDasharray="3 3" />
                             <XAxis type="number" />
                             <YAxis type="category" dataKey="name" width={80}/>
                             <Tooltip />
                             <Bar dataKey="count" fill="#d4a017" />
                         </BarChart>
                     </ResponsiveContainer>
                 </ChartContainer>
             </div>
        </div>
    );
};

export default Dashboard;
