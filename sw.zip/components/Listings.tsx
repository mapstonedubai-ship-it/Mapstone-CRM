
import React, { useState, useMemo } from 'react';
import { Listing, ListingStatus } from '../types';

interface ListingsProps {
    listings: Listing[];
}

const Listings: React.FC<ListingsProps> = ({ listings }) => {
    const [showApprovedOnly, setShowApprovedOnly] = useState(true);

    const filteredListings = useMemo(() => {
        return showApprovedOnly ? listings.filter(l => l.sellerApproval) : listings;
    }, [listings, showApprovedOnly]);

    const statusColorMap: Record<ListingStatus, string> = {
        [ListingStatus.Active]: 'bg-green-100 text-green-800',
        [ListingStatus.Sold]: 'bg-red-100 text-red-800',
        [ListingStatus.Rented]: 'bg-blue-100 text-blue-800',
        [ListingStatus.Archived]: 'bg-gray-100 text-gray-800',
    };

    const formatCurrency = (amount: number) => {
        return new Intl.NumberFormat('en-AE', { style: 'currency', currency: 'AED', minimumFractionDigits: 0 }).format(amount);
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-mapstone-dark">Property Listings</h2>
                <div className="flex items-center">
                    <label htmlFor="approved-toggle" className="mr-2 text-sm font-medium text-gray-700">Show Approved Only</label>
                    <input
                        id="approved-toggle"
                        type="checkbox"
                        checked={showApprovedOnly}
                        onChange={() => setShowApprovedOnly(!showApprovedOnly)}
                        className="h-4 w-4 rounded border-gray-300 text-mapstone-blue focus:ring-mapstone-blue"
                    />
                </div>
            </div>
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Property Name</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unit Type</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price (AED)</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            {!showApprovedOnly && (
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Seller Approval</th>
                            )}
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {filteredListings.map((listing) => (
                            <tr key={listing.id} className="hover:bg-gray-50">
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{listing.propertyName}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{listing.unitType}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{listing.location}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 font-semibold">{formatCurrency(listing.price)}</td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                     <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColorMap[listing.status]}`}>
                                        {listing.status}
                                    </span>
                                </td>
                                {!showApprovedOnly && (
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <span className={`inline-block h-4 w-4 rounded-full ${listing.sellerApproval ? 'bg-green-500' : 'bg-red-500'}`}></span>
                                    </td>
                                )}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default Listings;
