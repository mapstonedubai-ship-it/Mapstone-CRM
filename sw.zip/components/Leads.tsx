
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Lead, Agent, Language, LeadStatus } from '../types';
import { geminiService } from '../services/geminiService';
import { SparklesIcon } from './icons/SparklesIcon';

interface LeadsProps {
    leads: Lead[];
    agents: Agent[];
    onUpdateLead: (lead: Lead) => void;
}

const Leads: React.FC<LeadsProps> = ({ leads, agents, onUpdateLead }) => {
    const [localLeads, setLocalLeads] = useState<Lead[]>(leads);
    const [loadingMessages, setLoadingMessages] = useState<Record<number, boolean>>({});
    const [statusFilter, setStatusFilter] = useState<LeadStatus | 'all'>('all');
    const [agentFilter, setAgentFilter] = useState<string>('all'); // Use string for select value

    const getAgentName = (agentId?: number) => agents.find(a => a.id === agentId)?.name || 'Unassigned';

    const generateAIMessage = useCallback(async (lead: Lead) => {
        if (!lead.assignedAgent || lead.aiSuggestedMessage) return;

        setLoadingMessages(prev => ({ ...prev, [lead.id]: true }));
        try {
            const agentName = getAgentName(lead.assignedAgent);
            const message = await geminiService.generateContactMessage(lead.name, lead.language, agentName);
            const updatedLead = { ...lead, aiSuggestedMessage: message };
            
            // We update the local state for immediate UI feedback
            setLocalLeads(currentLeads => currentLeads.map(l => l.id === lead.id ? updatedLead : l));
            
            // And call the parent's update function to persist the change
            onUpdateLead(updatedLead);

        } catch (error) {
            console.error("Failed to generate AI message:", error);
        } finally {
            setLoadingMessages(prev => ({ ...prev, [lead.id]: false }));
        }
    }, [agents, onUpdateLead]);

    useEffect(() => {
        localLeads.forEach(lead => {
            if (!lead.aiSuggestedMessage && lead.assignedAgent) {
                generateAIMessage(lead);
            }
        });
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []); // Run only once on mount to generate initial messages

    useEffect(() => {
        setLocalLeads(leads);
    }, [leads]);
    
    const filteredLeads = useMemo(() => {
        return localLeads.filter(lead => {
            const statusMatch = statusFilter === 'all' || lead.status === statusFilter;
            const agentId = parseInt(agentFilter, 10);
            const agentMatch = agentFilter === 'all' || lead.assignedAgent === agentId;
            return statusMatch && agentMatch;
        });
    }, [localLeads, statusFilter, agentFilter]);

    const statusColorMap: Record<LeadStatus, string> = {
        [LeadStatus.Lead]: 'bg-blue-100 text-blue-800',
        [LeadStatus.Contacted]: 'bg-yellow-100 text-yellow-800',
        [LeadStatus.Negotiation]: 'bg-purple-100 text-purple-800',
        [LeadStatus.Closed]: 'bg-green-100 text-green-800',
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-bold text-mapstone-dark mb-4">Leads Management</h2>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <div>
                    <label htmlFor="status-filter" className="block text-sm font-medium text-gray-700">Filter by Status</label>
                    <select
                        id="status-filter"
                        name="status-filter"
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value as LeadStatus | 'all')}
                        className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-mapstone-blue focus:border-mapstone-blue sm:text-sm rounded-md"
                    >
                        <option value="all">All Statuses</option>
                        {Object.values(LeadStatus).map(status => (
                            <option key={status} value={status}>{status}</option>
                        ))}
                    </select>
                </div>
                 <div>
                    <label htmlFor="agent-filter" className="block text-sm font-medium text-gray-700">Filter by Agent</label>
                    <select
                        id="agent-filter"
                        name="agent-filter"
                        value={agentFilter}
                        onChange={(e) => setAgentFilter(e.target.value)}
                        className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-mapstone-blue focus:border-mapstone-blue sm:text-sm rounded-md"
                    >
                        <option value="all">All Agents</option>
                        {agents.map(agent => (
                            <option key={agent.id} value={agent.id.toString()}>{agent.name}</option>
                        ))}
                    </select>
                </div>
            </div>

            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Language</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Assigned Agent</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">AI Suggested Message</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {filteredLeads.map((lead) => (
                            <tr key={lead.id} className="hover:bg-gray-50">
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{lead.name}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    <div>{lead.phone}</div>
                                    <div>{lead.email}</div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{lead.language}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{getAgentName(lead.assignedAgent)}</td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColorMap[lead.status]}`}>
                                        {lead.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-sm text-gray-500">
                                    {loadingMessages[lead.id] ? (
                                        <div className="flex items-center">
                                            <SparklesIcon className="h-5 w-5 text-mapstone-accent animate-pulse mr-2" />
                                            <span>Generating...</span>
                                        </div>
                                    ) : (
                                        <div className="whitespace-pre-wrap text-xs">{lead.aiSuggestedMessage || 'No message generated.'}</div>
                                    )}
                                </td>
                            </tr>
                        ))}
                        {filteredLeads.length === 0 && (
                            <tr>
                                <td colSpan={6} className="text-center py-10 text-gray-500">
                                    No leads match the current filters.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default Leads;