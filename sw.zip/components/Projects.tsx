
import React, { useState } from 'react';
import { Project, Language, ProjectType } from '../types';
import { geminiService } from '../services/geminiService';
import { SparklesIcon } from './icons/SparklesIcon';

interface ProjectsProps {
    projects: Project[];
    onUpdateProject: (project: Project) => void;
}

const Projects: React.FC<ProjectsProps> = ({ projects, onUpdateProject }) => {
    const [localProjects, setLocalProjects] = useState<Project[]>(projects);
    const [loadingPresentations, setLoadingPresentations] = useState<Record<number, boolean>>({});

    const generateAIPresentation = async (project: Project, lang: Language) => {
        if (!lang) return;

        setLoadingPresentations(prev => ({ ...prev, [project.id]: true }));
        try {
            const presentation = await geminiService.generateProjectPresentation(project, lang);
            const updatedProject = { ...project, aiPresentation: presentation, languageOfPresentation: lang };
            
            setLocalProjects(current => current.map(p => p.id === project.id ? updatedProject : p));
            onUpdateProject(updatedProject);

        } catch (error) {
            console.error("Failed to generate AI presentation:", error);
        } finally {
            setLoadingPresentations(prev => ({ ...prev, [project.id]: false }));
        }
    };
    
    const typeColorMap: Record<ProjectType, string> = {
        [ProjectType.OffPlan]: 'bg-indigo-100 text-indigo-800',
        [ProjectType.Ready]: 'bg-teal-100 text-teal-800',
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-bold text-mapstone-dark mb-4">Projects</h2>
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Project</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Details</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Generate Presentation</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">AI Presentation</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {localProjects.map((project) => (
                            <tr key={project.id}>
                                <td className="px-6 py-4 align-top">
                                    <div className="text-sm font-medium text-gray-900">{project.projectName}</div>
                                    <div className="text-sm text-gray-500">{project.developer}</div>
                                     <div className="mt-2">
                                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${typeColorMap[project.projectType]}`}>
                                            {project.projectType}
                                        </span>
                                    </div>
                                </td>
                                <td className="px-6 py-4 align-top text-sm text-gray-500">
                                    <p><b>Location:</b> {project.location}</p>
                                    <p><b>Units:</b> {project.unitTypes.join(', ')}</p>
                                    <p><b>Handover:</b> {project.handoverDate}</p>
                                    <p><b>Price:</b> {project.priceRange}</p>
                                </td>
                                <td className="px-6 py-4 align-top">
                                    <div className="flex items-center space-x-2">
                                        <select
                                            onChange={(e) => generateAIPresentation(project, e.target.value as Language)}
                                            className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-mapstone-blue focus:border-mapstone-blue sm:text-sm rounded-md"
                                            defaultValue=""
                                            disabled={loadingPresentations[project.id]}
                                        >
                                            <option value="" disabled>Select Language</option>
                                            {Object.values(Language).map(lang => <option key={lang} value={lang}>{lang}</option>)}
                                        </select>
                                    </div>
                                </td>
                                <td className="px-6 py-4 align-top text-sm text-gray-500">
                                    {loadingPresentations[project.id] ? (
                                        <div className="flex items-center">
                                            <SparklesIcon className="h-5 w-5 text-mapstone-accent animate-pulse mr-2" />
                                            <span>Generating...</span>
                                        </div>
                                    ) : (
                                        <div className="whitespace-pre-wrap text-xs">{project.aiPresentation || 'Generate a presentation.'}</div>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default Projects;
