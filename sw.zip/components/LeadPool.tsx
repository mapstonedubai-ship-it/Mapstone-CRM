
import React from 'react';
import { LeadPoolLead, Agent } from '../types';

interface LeadPoolProps {
    leads: LeadPoolLead[];
    agents: Agent[];
    onClaimLead: (leadId: number, agentId: number) => void;
}

const LeadPool: React.FC<LeadPoolProps> = ({ leads, agents, onClaimLead }) => {
    
    // For simplicity, we'll let the user claim a lead for the first agent in the list.
    // In a real app, this would be the logged-in agent.
    const claimingAgentId = agents[0]?.id;

    return (
        <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-bold text-mapstone-dark mb-4">Lead Pool</h2>
            <p className="text-gray-600 mb-6">These are unassigned leads. Claim one to add it to your pipeline. (Claims for '{agents.find(a => a.id === claimingAgentId)?.name}')</p>
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Language</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {leads.map((lead) => (
                            <tr key={lead.id} className="hover:bg-gray-50">
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{lead.name}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    <div>{lead.phone}</div>
                                    <div>{lead.email}</div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{lead.language}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <button
                                        onClick={() => onClaimLead(lead.id, claimingAgentId)}
                                        className="bg-mapstone-accent text-white px-4 py-2 rounded-md hover:bg-yellow-600 transition duration-200 disabled:bg-gray-300"
                                        disabled={!claimingAgentId}
                                    >
                                        Claim
                                    </button>
                                </td>
                            </tr>
                        ))}
                        {leads.length === 0 && (
                           <tr>
                                <td colSpan={4} className="text-center py-10 text-gray-500">The Lead Pool is empty.</td>
                           </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default LeadPool;
