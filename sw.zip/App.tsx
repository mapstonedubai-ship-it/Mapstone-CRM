
import React, { useState, useCallback } from 'react';
import { Agent, Lead, Listing, Project, View } from './types';
import { AGENTS, LEADS, LEAD_POOL, LISTINGS, PROJECTS } from './data/mockData';
import Dashboard from './components/Dashboard';
import Leads from './components/Leads';
import LeadPool from './components/LeadPool';
import Listings from './components/Listings';
import Projects from './components/Projects';
import Agents from './components/Agents';
import { BuildingOfficeIcon } from './components/icons/BuildingOfficeIcon';

const App: React.FC = () => {
    const [currentView, setCurrentView] = useState<View>(View.Dashboard);
    const [leads, setLeads] = useState<Lead[]>(LEADS);
    const [leadPool, setLeadPool] = useState<Lead[]>(LEAD_POOL);
    const [listings, setListings] = useState<Listing[]>(LISTINGS);
    const [projects, setProjects] = useState<Project[]>(PROJECTS);
    const [agents, setAgents] = useState<Agent[]>(AGENTS);

    const claimLead = useCallback((leadId: number, agentId: number) => {
        const leadToClaim = leadPool.find(l => l.id === leadId);
        if (leadToClaim) {
            const newLead: Lead = {
                ...leadToClaim,
                id: leads.length + 100, // new ID
                assignedAgent: agentId,
                status: 'Lead',
                agentComments: '',
                aiSuggestedMessage: ''
            };
            setLeads(prev => [...prev, newLead]);
            setLeadPool(prev => prev.filter(l => l.id !== leadId));
        }
    }, [leadPool, leads.length]);
    
    const updateLead = (updatedLead: Lead) => {
        setLeads(leads.map(lead => lead.id === updatedLead.id ? updatedLead : lead));
    };

    const updateProject = (updatedProject: Project) => {
        setProjects(projects.map(p => p.id === updatedProject.id ? updatedProject : p));
    };

    const renderView = () => {
        switch (currentView) {
            case View.Dashboard:
                return <Dashboard leads={leads} listings={listings} projects={projects} leadPoolCount={leadPool.length} agents={agents} />;
            case View.Leads:
                return <Leads leads={leads} agents={agents} onUpdateLead={updateLead} />;
            case View.LeadPool:
                return <LeadPool leads={leadPool} agents={agents} onClaimLead={claimLead} />;
            case View.Listings:
                return <Listings listings={listings} />;
            case View.Projects:
                return <Projects projects={projects} onUpdateProject={updateProject} />;
            case View.Agents:
                return <Agents agents={agents} leads={leads} />;
            default:
                return <Dashboard leads={leads} listings={listings} projects={projects} leadPoolCount={leadPool.length} agents={agents} />;
        }
    };

    const NavItem = ({ view, label }: { view: View; label: string }) => (
        <button
            onClick={() => setCurrentView(view)}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors duration-200 ${
                currentView === view
                    ? 'bg-mapstone-accent text-white shadow-md'
                    : 'text-gray-200 hover:bg-mapstone-blue'
            }`}
        >
            {label}
        </button>
    );

    return (
        <div className="min-h-screen bg-mapstone-light text-gray-800 font-sans">
            <header className="bg-mapstone-dark shadow-lg">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center justify-between h-20">
                        <div className="flex items-center">
                            <BuildingOfficeIcon className="h-8 w-8 text-mapstone-accent" />
                            <h1 className="ml-3 text-2xl font-bold text-white tracking-wider">
                                MAPSTONE <span className="font-light">Real Estate CRM</span>
                            </h1>
                        </div>
                        <nav className="hidden md:flex space-x-2">
                            <NavItem view={View.Dashboard} label="Dashboard" />
                            <NavItem view={View.Leads} label="Leads" />
                            <NavItem view={View.LeadPool} label="Lead Pool" />
                            <NavItem view={View.Listings} label="Listings" />
                            <NavItem view={View.Projects} label="Projects" />
                            <NavItem view={View.Agents} label="Agents" />
                        </nav>
                    </div>
                </div>
            </header>
            <main className="container mx-auto p-4 sm:p-6 lg:p-8">
                {renderView()}
            </main>
        </div>
    );
};

export default App;
